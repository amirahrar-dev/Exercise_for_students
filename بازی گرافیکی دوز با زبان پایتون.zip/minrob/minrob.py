import ctypes;ctypes.windll.shcore.SetProcessDpiAwareness(True)
from tkinter import *
from PIL import Image, ImageTk
import random
from tkinter import messagebox
from tkinter import ttk
game_BG_var=[]

root=Tk()
root.geometry("1500x800")
root.resizable(False,False)
root.title("بازی دوز")

button=[];label=[];frame=[];entry=[];combo=[];Pvar1="";Pvar2="";play="play";click_N=0
label_font_size="18";button_font_size="18"
class ui:
    def delete_ui():
        global button , label , frame , combo , entry , Pvar1 , Pvar2
        for i in range(0,len(button)):button[i].destroy()
        for i in range(0,len(entry)):entry[i].destroy()
        for i in range(0,len(combo)):combo[i].destroy()
        for i in range(0,len(label)):label[i].destroy()
        for i in range(0,len(frame)):frame[i].destroy()
        button=[];label=[];frame=[]

class game_ui:
    def start():
        ui.delete_ui()
        label.append(Label(root,text="مقادیر اولیه را مشخص کنید",font=("Arial", label_font_size)));label[0].pack()
        
        def start():
            try:
                if (int(combo[0].get())**(1/2))//1==(int(combo[0].get())**(1/2)):
                    if int(entry[0].get())<=int(combo[0].get()):
                        global Pvar1 , Pvar2
                        Pvar1=int(int(combo[0].get())**(1/2))
                        Pvar2=int(entry[0].get())
                        game_play.set_var(Pvar1,Pvar1,Pvar2);game_ui.game_ui(Pvar1,Pvar1)
                    else:messagebox.showerror("خطا","باید تعداد بمب ها کمتر ویا مساوی با تعداد خانه ها باشد")
                else:messagebox.showerror("خطا","تعداد خانه ها باید عددی مربع (رادیکال پذیر) باشد یعنی رادیکال آن عدد عددی صحیح باشد")
            except ValueError:
                if messagebox.askquestion("داده نامعتبر","داده های وارد شده نامعتبر هستند آیا می خواهید بازی با داده های پیش فرض استارت شود؟",icon="warning")=="yes":game_play.set_var(10,10,10);game_ui.game_ui(10,10)
        label.append(Label(root,text="تعداد خانه ها (باید عدد مربع (رادیکال پذیر) باشد مثال : 100)",font=("Arial", label_font_size)));label[1].pack()
        val=[]
        for i in range (0,100):val.append(i**2)
        combo.append(ttk.Combobox(root,width=50,font=("Arial", 18),values=val));combo[0].pack()
        label.append(Label(root,text="تعداد مین ها (باید کمتر از تعداد خانه ها باشد)",font=("Arial", label_font_size)));label[2].pack()
        entry.append(Entry(root,width=50,font=("Arial", 18)));entry[0].pack()

        button.append(Button(root,command=lambda:start(),text="شروع بازی",font=("Arial", button_font_size),width=50,height=3));button[0].pack(pady=10)
    def game_ui(row=5,column=5):
        ui.delete_ui()
        def myfunction(event):
            canvas0.configure(scrollregion=canvas0.bbox("all"),width=1000,height=750)
        frame1=Frame(root,relief=GROOVE,width=100,height=700,bd=1)
        frame1.grid(row=1,column=2,rowspan=30,columnspan=6)
        canvas0=Canvas(frame1)
        frame2=Frame(canvas0)
        scrollbar0=Scrollbar(frame1,orient="vertical",command=canvas0.yview)
        scrollbar1=Scrollbar(frame1,orient="horizontal",command=canvas0.xview)
        canvas0.configure(yscrollcommand=scrollbar0.set)
        canvas0.configure(xscrollcommand=scrollbar1.set)
        scrollbar0.grid(row=1,column=8,rowspan=30,sticky="ns")
        scrollbar1.grid(row=10,column=0,columnspan=30,sticky="we")
        canvas0.grid(row=1,column=2,columnspan=6)
        canvas0.create_window((0,0),window=frame2,anchor='nw')
        frame2.bind("<Configure>",myfunction)
        def scroll(event):
            delta = event.delta
            if delta > 0:canvas0.yview("scroll", -1, "units")
            elif delta < 0:canvas0.yview("scroll", 1, "units")
        frame2.bind("<MouseWheel>", scroll)
        
        button_BG_photo = Image.open ("./img/Untitled-1.png");button_BG_photo = button_BG_photo.resize ((50, 50))
        for i in range (0,row*column):
            button.append(Button(frame2,command=lambda i=i:game_play.click_in_button(i),text="",font=("Arial", button_font_size)));button[i].grid(row=i%row,column=i//column)
            button[i].image = ImageTk.PhotoImage (button_BG_photo);button[i].configure (image=button[i].image)
            button[i].bind("<MouseWheel>", scroll)



class game_play:
    def set_var(row=5,column=5,min=5):
        global game_BG_var
        game_BG_var=[]
        for i in range (0,row*column):game_BG_var.append("")
        i=0
        while i<min:
            min_number=random.randint(0,row*column-1)
            if game_BG_var[min_number]!="-":game_BG_var[min_number]="-";i+=1
        for i in range (0,len(game_BG_var)):
            if game_BG_var[i]!="-":
                n=0;R=1;C=2
                if i%row==0:R=0
                if (i+1)%row==0:C=1

                for j in range (i-row-R,i-row+C):
                    if j<0:continue
                    if game_BG_var[j]=="-":n+=1
                for j in range (i+row-R,i+row+C):
                    if j>=len(game_BG_var):break
                    if game_BG_var[j]=="-":n+=1
                if i-R>0 and game_BG_var[i-R]=="-":n+=1
                if (i+1)%row!=0 and i+1<len(game_BG_var) and game_BG_var[i+1]=="-":n+=1

                game_BG_var[i]=str(n)
    def click_in_button(button_number):
        global play , click_N , Pvar1 , Pvar2
        if play=="play":
            if game_BG_var[button_number]=="-":
                button_BG_photo = Image.open ("./img/bomb.png");button_BG_photo = button_BG_photo.resize ((50, 50))
                for i in range (0,len(game_BG_var)):
                    button[i].config(bg="#FF0000")
                    if game_BG_var[i]=="-":button[i].image = ImageTk.PhotoImage (button_BG_photo);button[i].configure (image=button[i].image)
                play="game over"
                messagebox.showinfo("game over","game over")
            else:
                button_BG_photo = Image.open ("./img/"+str(game_BG_var[button_number])+".png");button_BG_photo = button_BG_photo.resize ((50, 50))
                button[button_number].image = ImageTk.PhotoImage (button_BG_photo);button[button_number].configure (image=button[button_number].image)
                click_N+=1
                if click_N==(Pvar1**2)-Pvar2:play="win";messagebox.showinfo("win","you win the game")

game_ui.start()
root.mainloop()